import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { BusService } from '../bus.service';
import { AdminDataService } from '../admin-data.service';
import { BusClass } from '../BusClass';
import { Bus } from '../Bus';

@Component({
  selector: 'app-update-details',
  templateUrl: './update-details.component.html',
  styleUrls: ['./update-details.component.css']
})
export class UpdateDetailsComponent implements OnInit {
  flag1: boolean;
  bus: BusClass[];
  currentBus: Bus;
  checkDateFlag:boolean;
  message: any;
  checkSeatFlag:boolean=false;
  checkLocationFlag:boolean;
  constructor(private adminSer: AdminDataService, private busSer: BusService, private router: Router) { }
  updateBus = new FormGroup({
    busId: new FormControl('', Validators.required),
    sourceStation: new FormControl('', Validators.required),
    destinationStation: new FormControl('', Validators.required),
    boardingTime: new FormControl('', Validators.required),
    dropTime: new FormControl('', Validators.required),
    busType: new FormControl('', Validators.required),
    fare: new FormControl('', Validators.required),
    totalSeats: new FormControl('', Validators.required),
    seatsBooked:new FormControl('',Validators.required)

  })
  ngOnInit(): void {
    this.adminSer.getBus().subscribe(data => this.bus = data);
    console.log(this.bus);
    this.currentBus = this.busSer.tempBus;
    console.log(this.currentBus);
    console.log(this.currentBus.busId);

  }

  updateBuses() {
    let busId = this.updateBus.get('busId').value;
    let sourceStation = this.updateBus.get('sourceStation').value;
    let destinationStation = this.updateBus.get('destinationStation').value;
    let boardingTime = this.updateBus.get('boardingTime').value;
    let dropTime = this.updateBus.get('dropTime').value;
    let busType = this.updateBus.get('busType').value;
    let fare = this.updateBus.get('fare').value;
    let totalSeats = this.updateBus.get('totalSeats').value;
    let seatNo = null;
    let seatsBooked = this.updateBus.get('seatsBooked').value;
    if(boardingTime>dropTime){
      this.checkDateFlag=true;
      }
    else{
      this.checkDateFlag=false;
    }
    if(seatsBooked>totalSeats){
     this.checkSeatFlag=true;
       }
    else {
           this.checkSeatFlag=false;
         }
  if(sourceStation.toLowerCase()===destinationStation.toLowerCase())
  {
    
    this.checkLocationFlag=true;
  }
  else {
    this.checkLocationFlag=false;
  }
    
    if(this.checkSeatFlag==false && this.checkLocationFlag==false && this.checkDateFlag==false){
    let tempAdd: BusClass = new BusClass(busId, sourceStation, destinationStation, boardingTime, dropTime, busType, totalSeats, fare, seatNo, seatsBooked);
    this.flag1 = true;
    this.adminSer.updateBus(tempAdd).subscribe(data => {
      console.log(data);
      this.message = "Bus updated successfully";
      document.getElementById("message").style.display = "block"
    });
  }
  }
  
}
