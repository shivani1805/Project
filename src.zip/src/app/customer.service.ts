import { Injectable } from '@angular/core';
import { Customer } from './Customer';
import { HttpHeaders, HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  localurl='./assets/busbooking.json';
  public tempCustomer:Customer;
  public flag:boolean=false;
  public customerDb:any[]=[];
  constructor(private http:HttpClient) { }
  httpOptions={
    headers:new HttpHeaders({
      'Content-Type':'application/json'
    })
}
  getCustomer()
  {
   this.http.get<Customer[]>('http://localhost:3000/Customer').subscribe(resp=>{
    for(const c of(resp as any)){
      this.customerDb.push({
        customerName:c.customerName,
    customerPhoneNumber:c.customerPhoneNumber,
    customerEmail:c.customerEmail,
    id:c.id,
    customerUserName:c.customerUserName,
    customerPassword:c.customerPassword,
    age:c.age
      })
    }
   console.log(this.customerDb);
   
   
  });
  }
  addCustomer(Customer:Customer)
  {
    return this.http.post('http://localhost:3000/Customer',Customer);
  }

  deleteCustomer(id:any)
  {
    return this.http.delete('http://localhost:3000/Customer/'+id);
  }
 
  updateCustomer(id:any,Customer:Customer)
  {
    return this.http.put('http://localhost:3000/Customer/'+id,Customer);
  }
}
