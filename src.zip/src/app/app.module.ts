import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserComponent } from './user/user.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, FormGroup, ReactiveFormsModule} from '@angular/forms';
import { BusService } from './bus.service';
import { RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { GenerateTicketComponent } from './generate-ticket/generate-ticket.component';
import { CancelTicketComponent } from './cancel-ticket/cancel-ticket.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { BusbookingComponent } from './busbooking/busbooking.component';
import { ChangeAgeComponent } from './change-age/change-age.component';
import { ChangeNameComponent } from './change-name/change-name.component';
import { ChangePhoneNumberComponent } from './change-phone-number/change-phone-number.component';
import { FeedbackRatingComponent } from './feedback-rating/feedback-rating.component';
import { EditProfileComponent } from './edit-profile/edit-profile.component';
import { AdminComponent } from './admin/admin.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { AdminfunctionComponent } from './admin/adminfunction/adminfunction.component';
// import { AddBusOrRouteComponent } from './add-bus-or-route/add-bus-or-route.component';
//import { UpdateDetailsComponent } from './update-details/update-details.component';
// import { GenerateReportComponent } from './generate-report/generate-report.component';
import { GenerateReportComponent } from './admin/adminfunction/generate-report/generate-report.component';
import { CancelBookingComponent } from './admin/adminfunction/cancel-booking/cancel-booking.component';
import { UpdateDetailsComponent } from './admin/adminfunction/update-details/update-details.component';
import { AddBusOrRouteComponent } from './admin/adminfunction/add-bus-or-route/add-bus-or-route.component';
import { UpdateArrivalComponent } from './admin/adminfunction/update-arrival/update-arrival.component';
import { UpdateSourceStationComponent } from './admin/adminfunction/update-source-station/update-source-station.component';
import { UpdateDestinationStationComponent } from './admin/adminfunction/update-destination-station/update-destination-station.component';
import { UpdateBusTypeComponent } from './admin/adminfunction/update-bus-type/update-bus-type.component';
import { UpdateDropTimeComponent } from './admin/adminfunction/update-drop-time/update-drop-time.component';
import { UpdateSeatsComponent } from './admin/adminfunction/update-seats/update-seats.component';
import { UpdateFareComponent } from './admin/adminfunction/update-fare/update-fare.component';

@NgModule({
  declarations: [
    AppComponent,
    UserComponent,
    HomeComponent,
    BusbookingComponent,
    GenerateTicketComponent,
    CancelTicketComponent,
    ChangePasswordComponent,
    BusbookingComponent,
    ChangeAgeComponent,
    ChangeNameComponent,
    ChangePhoneNumberComponent,
    FeedbackRatingComponent,
    EditProfileComponent,
    AdminComponent,
    ForgotPasswordComponent,
    AdminfunctionComponent,
   
    CancelBookingComponent,
   
  
    AddBusOrRouteComponent,
    UpdateDetailsComponent,
    GenerateReportComponent,
    UpdateArrivalComponent,
    UpdateSourceStationComponent,
    UpdateDestinationStationComponent,
    UpdateBusTypeComponent,
    UpdateDropTimeComponent,
    UpdateSeatsComponent,
    UpdateFareComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    RouterModule,
    ReactiveFormsModule
  ],
  providers: [BusService],
  bootstrap: [AppComponent]
})
export class AppModule { }
