import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateSourceStationComponent } from './update-source-station.component';

describe('UpdateSourceStationComponent', () => {
  let component: UpdateSourceStationComponent;
  let fixture: ComponentFixture<UpdateSourceStationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateSourceStationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateSourceStationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
