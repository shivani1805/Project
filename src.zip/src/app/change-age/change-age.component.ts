import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { Router } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';
import { Customer } from '../Customer';

@Component({
  selector: 'app-change-age',
  templateUrl: './change-age.component.html',
  styleUrls: ['./change-age.component.css']
})
export class ChangeAgeComponent implements OnInit {
  flag1:boolean;
  constructor(private custSer:CustomerService,private router:Router) { }
  changeage = new FormGroup({
    customerEmail: new FormControl(''),
    password: new FormControl(''),
    age: new FormControl('')
  })
    ngOnInit(): void 
    {
      this.custSer.getCustomer();
    }
  changeAge()
  {
  let customerEmail = this.changeage.get('customerEmail').value;
  let password=this.changeage.get('password').value;
  let age=this.changeage.get('age').value;
    for(let i=0;i<this.custSer.customerDb.length;i++) 
    {
      if ((this.custSer.customerDb[i].customerEmail == customerEmail)&&(this.custSer.customerDb[i].customerPassword==password))
      {
            this.custSer.customerDb[i].age=age;
            let tempCustomer:Customer=this.custSer.customerDb[i];
            this.custSer.updateCustomer(this.custSer.customerDb[i].id,tempCustomer).subscribe(data=>{console.log(data)});
            this.custSer.flag=true; 
      }     
    }
    if (this.custSer.flag) 
    {   
      this.flag1=true;
      this.router.navigateByUrl("/edit-profile");
    }
  }
}
