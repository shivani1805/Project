export class UserClass
{
    email:any;
    username:any;
    password:any;
    role:any;

    constructor(username,password,role,email){
        this.email=email;
        this.username=username;
        this.password=password;
        this.role=role;
    }
}