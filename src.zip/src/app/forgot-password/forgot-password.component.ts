import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { Router } from '@angular/router';
import { FormControl, FormGroup } from '@angular/forms';
import { UserClass } from '../userClass';
import { AdminDataService } from '../admin-data.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
  flag1:boolean;
  
  constructor(private adminSer:AdminDataService,private router:Router) { }
  forgotpassword = new FormGroup({
    email: new FormControl(''),
    username: new FormControl(''),
    newPassword: new FormControl(''),
    reNewPassword: new FormControl(''),
    role:new FormControl('')
  })
    ngOnInit(): void 
    {
      
    }
  forgotPassword()
  {
    
    let email = this.forgotpassword.get("email").value;
    let username=this.forgotpassword.get('username').value;
    let newPassword=this.forgotpassword.get('newPassword').value;
    let reNewPassword=this.forgotpassword.get('reNewPassword').value;
    let role="Admin";
      if(newPassword==reNewPassword){
        let tempUser:UserClass=new UserClass(username,newPassword,role,email);
        this.adminSer.changePassword(tempUser).subscribe(data => {
          if(!data)
          {
            this.flag1=false;
            window.alert("Invalid username or email");
            console.log(data);
          }
          else{
            console.log(data);
            this.flag1=true;
          }
        });
      
      }      else{
        window.alert("password did not match!");
                }
       
      }
  
     
      }
  

