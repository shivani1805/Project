import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Bus } from './Bus';
import { Observable } from 'rxjs';
import { map} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class BusServiceService {

  constructor(private http:HttpClient) { }
  httpOptions={
    headers:new HttpHeaders({
      'Content-Type':'application/json'
    })
}
  getBus()
  {
   return this.http.get("http://localhost:8080/api/bus");
  }

  addBus(bus:Bus)
  {
   return this.http.post("http://localhost:8080/api/addBus", bus,{responseType : 'json' as 'text'} );
  }
 
  
  deleteBus(id:any)
  {
    return this.http.delete("http://localhost:8080/api/delete"+id);
  }
 
  updateBus(id:any,Bus:Bus)
  {
    return this.http.put('http://localhost:8080/api/bus'+id,Bus);
  }
}
