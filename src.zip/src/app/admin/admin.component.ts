import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';



@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  constructor(private router: Router) { }


  loginAdmin = new FormGroup({
    adminEmail: new FormControl('', [Validators.email]),
    password: new FormControl('')
  });


  ngOnInit(): void {
    //this.custSer.getCustomer();
  }
  login() {

    let email = this.loginAdmin.get('adminEmail').value;
    let password = this.loginAdmin.get('password').value;

    if (email == "yash.bhatia@gmail.com" && password == "Yash@123") {
     
      this.router.navigate(['admin/adminfunction']);
    }


    else {
      window.alert("Invalid Admin login credential");
    }
  }

}
