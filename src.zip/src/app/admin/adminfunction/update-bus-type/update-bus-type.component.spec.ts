import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateBusTypeComponent } from './update-bus-type.component';

describe('UpdateBusTypeComponent', () => {
  let component: UpdateBusTypeComponent;
  let fixture: ComponentFixture<UpdateBusTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateBusTypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateBusTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
