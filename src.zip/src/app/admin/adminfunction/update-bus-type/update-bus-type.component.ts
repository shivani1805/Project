import { Component, OnInit } from '@angular/core';
import { BusService } from 'src/app/bus.service';
import { Router } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';
import { Bus } from 'src/app/Bus';

@Component({
  selector: 'app-update-bus-type',
  templateUrl: './update-bus-type.component.html',
  styleUrls: ['./update-bus-type.component.css']
})
export class UpdateBusTypeComponent implements OnInit {
  flag1:boolean;
  tempBus:Bus;

  constructor(private busSer:BusService,router:Router) { }

  updateBustype=new FormGroup({
    busId:new FormControl(''),
    busType:new FormControl('')
  })

  ngOnInit(): void {
    this.busSer.getBus();
  }

  updateBusType(){
    let busId=this.updateBustype.get('busId').value;
    let busType=this.updateBustype.get('busType').value;
    for(let i=0;i<this.busSer.busDb.length;i++)
    {
      if(this.busSer.busDb[i].id==busId)
      {
        this.busSer.busDb[i].busType=busType;
        this.tempBus=this.busSer.busDb[i];
        this.busSer.updateBus(this.busSer.busDb[i].id,this.tempBus).subscribe(data=>(console.log(data)));
        this.flag1=true;

      }
    }
  }

}
