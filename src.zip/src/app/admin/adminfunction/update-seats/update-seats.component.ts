import { Component, OnInit } from '@angular/core';
import { BusService } from 'src/app/bus.service';
import { Router } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';
import { Bus } from 'src/app/Bus';

@Component({
  selector: 'app-update-seats',
  templateUrl: './update-seats.component.html',
  styleUrls: ['./update-seats.component.css']
})
export class UpdateSeatsComponent implements OnInit {
  flag1:boolean;
  tempBus:Bus;

  constructor(private busSer:BusService,router:Router) { }
  updateSeat=new FormGroup({
    busId:new FormControl,
    totalSeats:new FormControl
  })

  ngOnInit(): void {
    this.busSer.getBus();
  }
  updateTotalSeats(){
    let totalSeats=this.updateSeat.get('totalSeats').value;
    let busId=this.updateSeat.get('busId').value;

    for(let i=0;i<this.busSer.busDb.length;i++)
    {
      if(this.busSer.busDb[i].id==busId)
      {
        this.busSer.busDb[i].totalSeats=totalSeats;
        this.tempBus=this.busSer.busDb[i];
        this.busSer.updateBus(this.busSer.busDb[i].id,this.tempBus).subscribe(data=>(console.log(data)));
        this.flag1=true;
      }
    }
  }


}
