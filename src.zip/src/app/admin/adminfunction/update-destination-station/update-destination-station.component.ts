import { Component, OnInit } from '@angular/core';
import { BusService } from 'src/app/bus.service';
import { Router } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';
import { Bus } from 'src/app/Bus';

@Component({
  selector: 'app-update-destination-station',
  templateUrl: './update-destination-station.component.html',
  styleUrls: ['./update-destination-station.component.css']
})
export class UpdateDestinationStationComponent implements OnInit {
  flag1:boolean;
  tempBus:Bus;

  constructor(private busSer:BusService,private router:Router) { }
  updateDestination=new FormGroup({
    busId:new FormControl(''),
    destinationStation:new FormControl('')
  })

  ngOnInit(): void {
    this.busSer.getBus();
  }
  
  updateDestinationStation(){
    let busId=this.updateDestination.get('busId').value;
    let destinationStation=this.updateDestination.get('destinationStation').value;
    for(let i=0;i<this.busSer.busDb.length;i++)
    {
      if(this.busSer.busDb[i].id==busId)
      {
        if(this.busSer.busDb[i].destinationStation!=destinationStation)
        {
        this.busSer.busDb[i].destinationStation=destinationStation;
        this.tempBus=this.busSer.busDb[i];
        this.busSer.updateBus(this.busSer.busDb[i].id,this.tempBus).subscribe(data=>(console.log(data)));
        this.flag1=true;
        }
        else
        window.alert("Entered Station is same as old one. Please enter a new Station.");
      }
    }

  }

}
