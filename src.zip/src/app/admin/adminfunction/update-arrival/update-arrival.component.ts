import { Component, OnInit } from '@angular/core';
import { BusService } from 'src/app/bus.service';
import { Router } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';
import { Bus } from 'src/app/Bus';


@Component({
  selector: 'app-update-arrival',
  templateUrl: './update-arrival.component.html',
  styleUrls: ['./update-arrival.component.css']
})
export class UpdateArrivalComponent implements OnInit {
  flag1:boolean;
  tempBus:Bus;
  constructor(private busSer:BusService,private router:Router) { }
  updatearrival = new FormGroup({
    busid : new FormControl(''),
    arrivalTime : new FormControl('')
  })

  ngOnInit(): void {
    this.busSer.getBus();
  }
  updateArrival()
  {
    let busid=this.updatearrival.get('busid').value;
    let arrivalTime=this.updatearrival.get('arrivalTime').value;
    for(let i=0;i<this.busSer.busDb.length;i++)
    {
       if(this.busSer.busDb[i].id==busid)
       {
         if(this.busSer.busDb[i].boardingTime!=arrivalTime)
         {
         this.busSer.busDb[i].boardingTime=arrivalTime;
         this.tempBus=this.busSer.busDb[i];
         this.busSer.updateBus(this.busSer.busDb[i].id,this.tempBus).subscribe(data=>{console.log(data)});
         this.flag1=true;
         }
         else
         window.alert("Entered time is same as old one. Please enter new time.")
       }
    } 
    //if(this.busSer.flag==true)
   // {
   //   this.flag1=true;
     // this.router.navigate(['/admin/adminfunction/update-details']);
    
  }
}