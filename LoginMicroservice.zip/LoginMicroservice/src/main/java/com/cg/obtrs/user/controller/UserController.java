package com.cg.obtrs.user.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.obtrs.user.entities.UserEntity;
import com.cg.obtrs.user.service.UserService;
import org.springframework.web.bind.annotation.PutMapping;
@RestController
@RequestMapping("/user")
@CrossOrigin("http://localhost:4200")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@GetMapping("/login")
	boolean login(@RequestBody UserEntity user) {
		return userService.login(user);
	}
  
	@PutMapping("/changePassword")
	boolean changePassword(@RequestBody UserEntity user) {
		return userService.changePassword(user);
	}
	
}
