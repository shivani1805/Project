package com.cg.obtrs.user.service;

import com.cg.obtrs.user.entities.UserEntity;

public interface UserService {

	boolean login(UserEntity user);
	boolean changePassword(UserEntity user);
	
}
