package com.cg.obtrs.user.service;

import com.cg.obtrs.user.dao.UserDao;
import com.cg.obtrs.user.entities.UserEntity;

import org.springframework.stereotype.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private UserDao userDao;
	
	@Override
	public boolean login(UserEntity user) {
		List<UserEntity> userList=  userDao.findAll();
		for(int i=0;i<userList.size();i++) {
		  if(user.equals(userList.get(i))){
			
				return true;
			}
		}
		return false;
	}
	
	@Override
	public boolean changePassword(UserEntity user) {
		List<UserEntity> userList=userDao.findAll();
		boolean flag=false;
		String email=user.getEmail();
		String username=user.getUsername();
		for(int i=0;i<userList.size();i++) {
			if(email.equals(userList.get(i).getEmail()) && username.equals(userList.get(i).getUsername())){
				userDao.save(user);
				flag=true;
			}
		}
		if(flag==true) {
			return true;
		}
		else {
			return false;
		}
	}
}

