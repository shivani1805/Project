package com.cg.obtrs.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import com.cg.obtrs.dto.BookingDTO;
import com.cg.obtrs.dto.BusDTO;
import com.cg.obtrs.dto.CustomerDTO;
import com.cg.obtrs.exception.CustomException;

public class CustomerDAOImpl implements CustomerDAO 
{
	BookingDTO bookingDto;
	@Override
	public String customerSignUp(String name, long phoneNumber, String email, int custId, String userName, String password) throws CustomException
	{
		StaticDb.custList.add(new CustomerDTO(name,phoneNumber,email,custId,userName,password));
		return "\n********************************************************************************SIGNUP SUCCESSFULL********************************************************************************";
	}

	@Override
	public String customerLoginIn(String userName, String password) throws CustomException 
	{
		int flag = 0;
		for (CustomerDTO cust : StaticDb.custList) 
		{
			if (cust.getCustUserName().equals(userName) && cust.getCustPassword().equals(password)) 
			{
				flag = 1;
				break;
			}

		}
		if (flag == 1)
			return "********************************************************************************LOGIN SUCCESSFULL***************************************************************************"+"\n\tOPTIONS:";
		else
			throw new CustomException("USERNAME OR PASSWORD IS INCORRECT");
	}

	@Override
	public boolean changePassword(String custEmail, String currentPassword, String newPassword) throws CustomException 
	{
		int flag = 0;
		for (int i = 0; i < StaticDb.custList.size(); i++) 
		{
			if (custEmail.equals(StaticDb.custList.get(i).getCustEmail())) 
			{
				StaticDb.custList.get(i).setCustPassword(newPassword);
				flag = 1;
			}
		}
		if (flag == 1)
			return true;
		else
			throw new CustomException("CAN'T CHANGE PASSWORD");
	}

	@Override
	public List<BusDTO> searchBus(String sourceStation, String destinationStation) throws CustomException 
	{
		List<BusDTO> searchList = new ArrayList<>();
		for (BusDTO bus : StaticDb.busList.values())
		{
			if(bus.getSourceStation().equalsIgnoreCase(sourceStation) && bus.getDestinationStation().equalsIgnoreCase(destinationStation))
				searchList.add(bus);
		}
		if(searchList.isEmpty())
			throw new CustomException("NO BUSES FOUND");
		return searchList;
	}
	public Integer checkSeatAvailability(int busId) throws CustomException 
	{
		BusDTO busDto = StaticDb.busList.get(busId);
		int totalSeats = busDto.getTotalSeats();
		int seatsBooked = busDto.getSeatsBooked();
		int seatsAvailable = totalSeats-seatsBooked;
		return seatsAvailable;
	}

	@Override
	public boolean validatePassword(String email, String userName) throws CustomException 
	{
		for(CustomerDTO temp:StaticDb.custList)
		{
			if(temp.getCustEmail().equalsIgnoreCase(email)&& (temp.getCustUserName().equals(userName)))
				return true;
		}
		return false;
	}

	@Override
	public boolean forgetPassword(String email, String userName,String newPassword) throws CustomException 
	{
		for(CustomerDTO temp:StaticDb.custList)
		{
			if(temp.getCustEmail().equalsIgnoreCase(email)&& (temp.getCustUserName().equals(userName)))
			{
				temp.setCustPassword(newPassword);
				return true;
			}
		}
		return false;
	}

	@Override
	public List<BusDTO> sortBusByDepartureTime(String sourceStation, String destinationStation) throws CustomException 
	{
		ArrayList<BusDTO> sortBusList=new ArrayList<BusDTO>();
		for (BusDTO bus : StaticDb.busList.values())
		{
			if(bus.getSourceStation().equalsIgnoreCase(sourceStation) && bus.getDestinationStation().equalsIgnoreCase(destinationStation))
				sortBusList.add(bus);
		}
		if(sortBusList.isEmpty())
			throw new CustomException("NO BUSES FOUND");
		Collections.sort(sortBusList, BusDTO.departureComparator);
		return sortBusList;
	}

	@Override
	public List<BusDTO> sortBusByArrivalTime(String sourceStation, String destinationStation) throws CustomException {
		ArrayList<BusDTO> sortBusList=new ArrayList<BusDTO>();
		for (BusDTO bus : StaticDb.busList.values())
		{
			if(bus.getSourceStation().equalsIgnoreCase(sourceStation) && bus.getDestinationStation().equalsIgnoreCase(destinationStation))
				sortBusList.add(bus);
		}
		if(sortBusList.isEmpty())
			throw new CustomException("NO BUSES FOUND");
		Collections.sort(sortBusList, BusDTO.arrivalComparator);
		return sortBusList;
	}
    
    
}
