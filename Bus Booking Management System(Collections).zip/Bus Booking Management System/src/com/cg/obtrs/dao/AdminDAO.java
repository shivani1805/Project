package com.cg.obtrs.dao;

import java.time.LocalDateTime;
import java.util.ArrayList;
import com.cg.obtrs.dto.AdminDTO;
import com.cg.obtrs.dto.BookingDTO;
import com.cg.obtrs.dto.BusDTO;
import com.cg.obtrs.exception.CustomException;

public interface AdminDAO {

	public String adminSignUp(AdminDTO adminDto) throws CustomException;

	public String adminLoginIn(String userName, String password)throws CustomException;

	public ArrayList<BusDTO> addBusOrRoute(int busId, String sourceStation, String destinationStation,
			LocalDateTime boardingTime, LocalDateTime dropTime, String busType, Integer totalSeats, Float fare);

	public ArrayList<BookingDTO> generateReport()throws CustomException;

	public String cancelBooking(int busId, int bookingId) throws CustomException;

	public ArrayList<BusDTO> updateSourceStation(int busId, String sourceStation);

	public ArrayList<BusDTO> updateDestinationStation(int busId, String destinationStation);

	public ArrayList<BusDTO> updateBoardingTime(int busId, LocalDateTime boardingTime)throws CustomException;

	public ArrayList<BusDTO> updateDropTime(int busId, LocalDateTime dropTime)throws CustomException;

	public ArrayList<BusDTO> updateBustype(int busId, String busType);

	public ArrayList<BusDTO> updateTotalSeats(int busId, int totalSeats)throws CustomException;

	public ArrayList<BusDTO> updateFare(int busId, Float fare)throws CustomException;
	
	public boolean validatePassword(String email, String userName) throws CustomException;
	public boolean forgotPassword(String email, String userName,String newPassword) throws CustomException;
	
	  public void validateBusId(int busId,String function)throws CustomException;
}