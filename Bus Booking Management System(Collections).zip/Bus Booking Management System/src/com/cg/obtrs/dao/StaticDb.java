package com.cg.obtrs.dao;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;

import java.util.Map;

import com.cg.obtrs.dto.BookingDTO;
import com.cg.obtrs.dto.BusDTO;

import com.cg.obtrs.dto.AdminDTO;

import com.cg.obtrs.dto.CustomerDTO;

public class StaticDb 
{
 static public ArrayList<CustomerDTO> custList = new ArrayList<>();
 static public Map<Integer,BusDTO> busList = new HashMap<>(); 
 static public ArrayList<AdminDTO> adminList=new ArrayList<>();
 static public Map<Integer, BookingDTO> bookingList = new HashMap<>();
 static public ArrayList<BookingDTO> detailsList= new ArrayList<>();
 
 
//Pre-populated Bus List Data
 static
 {
		busList.put(111, new BusDTO(111,"Delhi","Lucknow", LocalDateTime.of(2020, 05, 10, 5, 29), LocalDateTime.of(2020, 05, 10, 10, 50),"Volvo",35,900.0F,"16(B)",11));
		busList.put(140, new BusDTO(140,"Delhi","Lucknow", LocalDateTime.of(2020, 05, 05, 13, 30), LocalDateTime.of(2020, 05, 05, 18, 30),"AC BUS",40,950.0F,"16(B)",11));
		busList.put(120, new BusDTO(120,"Mumbai","Pune",LocalDateTime.of(2020, 05, 18, 15, 30), LocalDateTime.of(2020, 05, 18, 18, 15),"AC Bus",40,1200.0F,"17(F)", 4));
		busList.put(109, new BusDTO(109,"Ahemdabad","Gandhinagar",LocalDateTime.of(2020, 05, 01, 11, 30), LocalDateTime.of(2020, 05, 01, 17, 30),"Non-AC Bus",44,1050.0F,"18(G)", 0));
		busList.put(112, new BusDTO(112,"Talawade","Ahmednagar",LocalDateTime.of(2020, 05, 04, 14, 50), LocalDateTime.of(2020, 05, 04, 17, 45),"Double-Decker",47,500.0F,"02(B)", 12));
	}
 
//Pre-populated Customer List Data
static
{
	custList.add(new CustomerDTO("Amaan Ahmad",7894561235L,"amaan.ahmad7@gmail.com",1231,"amaahmad","amaan123"));
	custList.add(new CustomerDTO("Yash Bhatia",7984651324L,"yash.bhatia@gmail.com",1241,"ybhatia","y@$hbhatia"));
	custList.add(new CustomerDTO("Shivani Sharma",7964581325L,"shivani.sharma@gmail.com",1272,"ssharma","shivani1235"));
	custList.add(new CustomerDTO("Shivam Singh",8563030333L,"shivamsingh7455@gmail.com",1273,"Shivam2610","Shivam@123"));
	

}
static 
{ 

	bookingList.put(100003,new BookingDTO(111,new String[] {"Amaan","Rohan","Rohit","Aman","Ram"},5,5445));
	bookingList.put(100005,new BookingDTO(111,new String[] {"Yash","Rohan","Rohit","Aman","Ram", "Neelesh"}, 6,4567));
	bookingList.put(100007,new BookingDTO(120,new String[] {"Shivani","Rohan","Rohit","Aman"},4,4567));
	bookingList.put(100034,new BookingDTO(112,new String[] {"Sumit","Rohan","Rohit","Aman","Ram"}, 5,4500));
	bookingList.put(100053,new BookingDTO(112,new String[] {"Shivam","Rohan","Rohit","Aman"}, 4,5000));
}
static {
	adminList.add(new AdminDTO("Shivani",9854321567L,"shivani.sharma@gmail.com",1001,"ssharma","Shivani@1"));
}
}



 
