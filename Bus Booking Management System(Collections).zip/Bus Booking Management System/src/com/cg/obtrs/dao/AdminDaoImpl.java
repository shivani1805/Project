package com.cg.obtrs.dao;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Map;
import java.util.Map.Entry;

import com.cg.obtrs.dto.AdminDTO;
import com.cg.obtrs.dto.BookingDTO;
import com.cg.obtrs.dto.BusDTO;
import com.cg.obtrs.dto.CustomerDTO;
import com.cg.obtrs.exception.CustomException;

public class AdminDaoImpl implements AdminDAO {

	@Override
	public String adminSignUp(AdminDTO adminDto) throws CustomException {

		StaticDb.adminList.add(adminDto);
		return "Signup Successfull";
	}

	@Override
	public String adminLoginIn(String userName, String password)throws CustomException {

		int flag = 0;
		for (AdminDTO admin : StaticDb.adminList) {
			if (admin.getAdminUserName().equals(userName) && admin.getAdminPassword().equals(password)) {
				flag = 1;
				break;
			}

		}
		if (flag == 1)
			return "*****************Login Successful*******************";
		else
			throw new CustomException("Username or password is incorrect");
	}

	public ArrayList<BusDTO> addBusOrRoute(int busId, String sourceStation, String destinationStation,
			LocalDateTime boardingTime, LocalDateTime dropTime, String busType, Integer totalSeats, Float fare) {
		BusDTO newBus = new BusDTO();
		newBus.setBusId(busId);
		newBus.setSourceStation(sourceStation);
		newBus.setDestinationStation(destinationStation);
		newBus.setBoardingTime(boardingTime);
		newBus.setDropTime(dropTime);
		newBus.setFare(fare);
		newBus.setBusType(busType);
		newBus.setTotalSeats(totalSeats);
		StaticDb.busList.put(newBus.getBusId(), newBus);
		
		ArrayList<BusDTO> updateList = new ArrayList<>();
		for (Entry<Integer, BusDTO> updateEntry : StaticDb.busList.entrySet())

			updateList.add(updateEntry.getValue());

		return updateList;
	}

	@Override
	public ArrayList<BookingDTO> generateReport()throws CustomException {
		ArrayList<BookingDTO> reportList = new ArrayList<>();
		if (StaticDb.bookingList.size() == 0) {
			System.out.println("No records found");
		} else {
			for (Entry<Integer, BookingDTO> entry : StaticDb.bookingList.entrySet())
				reportList.add(entry.getValue());

		}
		return reportList;
	}

	@Override
	public String cancelBooking(int busId, int bookingId) throws CustomException {
		if((!StaticDb.busList.containsKey(busId)) || (!StaticDb.bookingList.containsKey(bookingId)))
			throw new CustomException("Bus Id or Booking Id does not exist! Enter again :");
		else {
		BusDTO busDto = StaticDb.busList.get(busId);
		busDto.setSeatsBooked(busDto.getSeatsBooked() - 1);
		BookingDTO bookingDto = StaticDb.bookingList.get(bookingId);
		bookingDto.setSeatsBooked(bookingDto.getSeatsBooked() - 1);
		return "Cancellation Successfull........\n" + "Refund has been initiated...........";
	}}

	@Override
	public ArrayList<BusDTO> updateSourceStation(int busId, String sourceStation) {
		BusDTO busDto = StaticDb.busList.get(busId);
		busDto.setSourceStation(sourceStation);
		ArrayList<BusDTO> updateList = new ArrayList<>();
		for (Entry<Integer, BusDTO> updateEntry : StaticDb.busList.entrySet())

			updateList.add(updateEntry.getValue());

		

		return updateList;
	}

	@Override
	public ArrayList<BusDTO> updateDestinationStation(int busId, String destinationStation) {

		BusDTO busDto = StaticDb.busList.get(busId);
		busDto.setDestinationStation(destinationStation);

		
		ArrayList<BusDTO> updateList = new ArrayList<>();
		for (Entry<Integer, BusDTO> entry : StaticDb.busList.entrySet()) {
			updateList.add(entry.getValue());
		}

		return updateList;

	}

	@Override
	public ArrayList<BusDTO> updateBoardingTime(int busId, LocalDateTime boardingTime)throws CustomException {
		if(boardingTime.isAfter(LocalDateTime.now())|| boardingTime.isEqual(LocalDateTime.now()))
		{
		BusDTO busDto = StaticDb.busList.get(busId);
		if(boardingTime.isBefore(busDto.getDropTime()))
		{
		busDto.setBoardingTime(boardingTime);
		}else throw new CustomException("Invalid Date or Time! Please enter again:");
	
		ArrayList<BusDTO> updateList = new ArrayList<>();
		for (Entry<Integer, BusDTO> entry : StaticDb.busList.entrySet())
			updateList.add(entry.getValue());

		return updateList;
		}else throw new CustomException("Invalid Date or Time! Please enter again:");
	}

	@Override
	public ArrayList<BusDTO> updateDropTime(int busId, LocalDateTime dropTime)throws CustomException {
		if(dropTime.isAfter(LocalDateTime.now()) || dropTime.isEqual(LocalDateTime.now()))
		{
		BusDTO busDto = StaticDb.busList.get(busId);
		if(dropTime.isAfter(busDto.getBoardingTime()))
		{	
		busDto.setDropTime(dropTime);
		}else
			throw new CustomException("Invalid Date or Time! Please enter again:");
	
		ArrayList<BusDTO> updateList = new ArrayList<>();
		for (Entry<Integer, BusDTO> entry : StaticDb.busList.entrySet())
			updateList.add(entry.getValue());

		return updateList;
		}else throw new CustomException("Invalid Date or Time! Please enter again:");
	}

	@Override
	public ArrayList<BusDTO> updateBustype(int busId, String busType) {
		BusDTO busDto = StaticDb.busList.get(busId);
		busDto.setBusType(busType);

		
		ArrayList<BusDTO> updateList = new ArrayList<>();
		for (Entry<Integer, BusDTO> entry : StaticDb.busList.entrySet())
			updateList.add(entry.getValue());

		return updateList;
	}

	@Override
	public ArrayList<BusDTO> updateTotalSeats(int busId, int totalSeats)throws CustomException {
		if(totalSeats>0) {
		BusDTO busDto = StaticDb.busList.get(busId);
		busDto.setTotalSeats(totalSeats);
		
		ArrayList<BusDTO> updateList = new ArrayList<>();
		for (Entry<Integer, BusDTO> entry : StaticDb.busList.entrySet())
			updateList.add(entry.getValue());

		return updateList;}
		else throw new CustomException("Invalid number of seats! Please enter again:");
	}

	@Override
	public ArrayList<BusDTO> updateFare(int busId, Float fare)throws CustomException {
		if(fare>0) {
		BusDTO busDto = StaticDb.busList.get(busId);
		busDto.setFare(fare);

	
		ArrayList<BusDTO> updateList = new ArrayList<>();
		for (Entry<Integer, BusDTO> entry : StaticDb.busList.entrySet())
			updateList.add(entry.getValue());

		return updateList;
		}
		else throw new CustomException("Invalid Fare! Please enter again:");

	}
	public boolean validatePassword(String email, String userName) throws CustomException{
		for(AdminDTO adminDto:StaticDb.adminList)
		{
			if(adminDto.getAdminEmail().equalsIgnoreCase(email)&& (adminDto.getAdminUserName().equals(userName)))
				return true;
		}
		return false;
	}
	public boolean forgotPassword(String email, String userName,String newPassword) throws CustomException {
		for(AdminDTO adminDto:StaticDb.adminList)
		{
			if(adminDto.getAdminEmail().equalsIgnoreCase(email)&& (adminDto.getAdminUserName().equals(userName)))
			{
				adminDto.setAdminPassword(newPassword);
				return true;
			}
		}
		return false;
	}
	  public void validateBusId(int busId,String function)throws CustomException {
		  if(StaticDb.busList.containsKey(busId) && function.equals("add")) {
			  throw new CustomException("Bus Id already exists! Enter new Bus ID:");
		  }
		  else if((!StaticDb.busList.containsKey(busId) && function.equals("update")))
				  {
			  throw new CustomException("Bus Id does not exist! Enter new Bus ID:" );
				  }
		
		  
		  
	  }
	
}