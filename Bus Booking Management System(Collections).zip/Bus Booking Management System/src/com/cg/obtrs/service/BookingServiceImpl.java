package com.cg.obtrs.service;

import java.util.List;
import com.cg.obtrs.dao.BookingDAO;
import com.cg.obtrs.dao.BookingDAOImpl;
import com.cg.obtrs.dao.StaticDb;
import com.cg.obtrs.exception.CustomException;

public class BookingServiceImpl implements BookingService
{
	BookingDAO bookingDao = new BookingDAOImpl();

	@Override
	public String bookSeat(List<String>passengerNames,int age, long cardNumber , int cardCvv, int busId, float totalFare) throws CustomException 
	{
		return bookingDao.bookSeat(passengerNames,age,cardNumber,cardCvv, busId,totalFare);
	}

	@Override
	public String generateTicket(int busId, int bookingId) throws CustomException 
	{
		return bookingDao.generateTicket(busId, bookingId);
	}

	@Override
	public float displayFare(int age, int busId) throws CustomException 
	{    
		boolean busIdFlag = false;
		for(int busIdinDb : StaticDb.busList.keySet())
		{
			if(busIdinDb==busId)
			{   
				busIdFlag = true;
			}
		}
		if(busIdFlag==true)
			return bookingDao.displayFare(age, busId);
		else
			throw new CustomException("Invalid Bus Id");
	}

	@Override
	public String cancelBooking(int bookingId, int busId) throws CustomException 
	{
		return bookingDao.cancelBooking(bookingId, busId);
	}

	@Override
	public float refundMoney(int bookingId) throws CustomException 
	{
		return bookingDao.refundMoney(bookingId);
	}
	
	@Override
	public String feedback(int bookingId,String feedBack, int rating) 
	{
		return bookingDao.feedback(bookingId,feedBack,rating);
	}

}
