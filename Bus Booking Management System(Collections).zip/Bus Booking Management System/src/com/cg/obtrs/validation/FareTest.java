package com.cg.obtrs.validation;

import static org.junit.Assert.*;

import org.junit.Test;

public class FareTest {
	  Validation validation = new Validation();
	@Test
	public void testFare() {
		boolean isFareValid = validation.isValidFare(450.75F);
		assertTrue(isFareValid);
	}

}
