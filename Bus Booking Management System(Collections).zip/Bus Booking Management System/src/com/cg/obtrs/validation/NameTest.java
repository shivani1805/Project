package com.cg.obtrs.validation;

import static org.junit.Assert.*;

import org.junit.Test;

public class NameTest {
            Validation validation = new Validation();
	@Test
	public void testName() {
	  boolean isNameValid = validation.isValidName("Amaan");
	  assertTrue(isNameValid); 
	}
	
	

}
