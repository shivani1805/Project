package com.cg.obtrs.validation;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ EmailTest.class, NameTest.class, PasswordTest.class, PhoneNumberTest.class, UsernameTest.class })
public class AllTests {

}
