package com.cg.obtrs.validation;

import static org.junit.Assert.*;

import org.junit.Test;

public class EmailTest {

    Validation validation = new Validation();
	@Test
	public void testEmail() {
	  boolean isEmailValid = validation.isValidEmail("amaan.ahmad@gmail.com");
	  assertTrue(isEmailValid); 
	}

}
