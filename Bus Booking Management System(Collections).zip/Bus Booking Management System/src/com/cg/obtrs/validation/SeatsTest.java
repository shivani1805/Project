package com.cg.obtrs.validation;

import static org.junit.Assert.*;

import org.junit.Test;

public class SeatsTest {
	  Validation validation = new Validation();
	@Test
	public void test() {
		boolean isSeatValid = validation.isValidSeats(35);
		assertTrue(isSeatValid);
	}

}
