package com.cg.obtrs.validation;

import static org.junit.Assert.*;

import org.junit.Test;

public class BusTypeTest {
	  Validation validation = new Validation();
	@Test
	public void test() {
		boolean isBusTypeValid=validation.isValidBusType("AC Bus");
		assertTrue(isBusTypeValid);
	}

}
