import { BusClass } from './../BusClass';
import { AdminDataService } from './../admin-data.service';
import { Component, OnInit } from '@angular/core';
import { BusService } from 'src/app/bus.service';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Bus } from 'src/app/Bus';
import { catchError } from 'rxjs/operators';
import { HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';

@Component({
  selector: 'app-update-bus-type',
  templateUrl: './update-bus-type.component.html',
  styleUrls: ['./update-bus-type.component.css']
})
export class UpdateBusTypeComponent implements OnInit {
  flag1:boolean;
  tempBus:Bus;
  bus:BusClass[];
  constructor(private adminSer:AdminDataService,private router:Router) { }

  updateBustype=new FormGroup({
    busId:new FormControl('',Validators.required),
    busType:new FormControl('',Validators.required)
  })

  ngOnInit(): void {
    this.adminSer.getBus().subscribe(data => this.bus=data);
  }

  updateBusType(){
    let busId=this.updateBustype.get('busId').value;
    let busType=this.updateBustype.get('busType').value;
    this.adminSer.updateBusByBusType(busId, busType).pipe(catchError((error:HttpErrorResponse)=>{
      this.router.navigate(["show-error",error.error.message]);
      return throwError(error.error.message)})).subscribe(data=>console.log(data));
    for(let i=0;i<this.bus.length;i++)
    {
      if(this.bus[i].busId==busId)
      {
        this.adminSer.updateBusByBusType(busId, busType).subscribe(data=>(console.log(data)));
        this.flag1=true;
      }
    }
      }
    
}
