import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { Router } from '@angular/router';
import { FormControl, FormGroup } from '@angular/forms';
import { Customer } from '../Customer';

@Component({
  selector: 'app-change-phone-number',
  templateUrl: './change-phone-number.component.html',
  styleUrls: ['./change-phone-number.component.css']
})
export class ChangePhoneNumberComponent implements OnInit {
  flag1:boolean;

  constructor(private custSer:CustomerService,private router:Router) { }
  changephonenumber = new FormGroup({
    customerEmail: new FormControl(''),
    password: new FormControl(''),
    phoneNumber: new FormControl('')
  })
    ngOnInit(): void 
    {
      this.custSer.getCustomer();
    }
  changePhoneNumber()
  {
  if(this.changephonenumber.valid)
  {
  let customerEmail = this.changephonenumber.get('customerEmail').value;
  let password=this.changephonenumber.get('password').value;
  let phoneNumber=this.changephonenumber.get('phoneNumber').value;
    for(let i=0;i<this.custSer.customerDb.length;i++) 
    {
      if (this.custSer.customerDb[i].customerEmail == customerEmail)
      {     
        if(this.custSer.customerDb[i].customerPassword==password)
        {
            this.custSer.customerDb[i].customerPhoneNumber=phoneNumber;
            let tempCustomer:Customer=this.custSer.customerDb[i];
            this.custSer.updateCustomer(this.custSer.customerDb[i].id,tempCustomer).subscribe(data=>{console.log(data)});
            this.custSer.flag=true;
        }
      }     
    }
    if (this.custSer.flag) 
    {
      this.flag1=true;
      this.router.navigateByUrl("/edit-profile");
    }
  }
  }
}
