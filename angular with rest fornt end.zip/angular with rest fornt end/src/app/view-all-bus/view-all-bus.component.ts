import { Component, OnInit } from '@angular/core';
import { Bus } from 'src/app/Bus';
import { Router } from '@angular/router';
import{BusService} from 'src/app/bus.service';
import { AdminDataService } from '../admin-data.service';
import { BusClass } from '../BusClass';

@Component({
  selector: 'app-view-all-bus',
  templateUrl: './view-all-bus.component.html',
  styleUrls: ['./view-all-bus.component.css']
})
export class ViewAllBusComponent implements OnInit {
  flag1:boolean=false;
  checkEmptyFlag:boolean;
  bus:BusClass[];
  
  constructor(private adminSer:AdminDataService,private router:Router) { }

  ngOnInit(): void {
    document.getElementById("busTable").style.display="none";
  }

  viewAllBus(){
    this.adminSer.getBus().subscribe(data=>this.bus=data);
    console.log(this.bus);
    document.getElementById("busTable").style.display="block";
    
}
}