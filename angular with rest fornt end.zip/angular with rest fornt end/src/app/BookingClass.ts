export class BookingClass
{
    
    bookingId : any;
    busId:any;
    passengerNames:any[];
    seatNo: any;
    seatsBooked:any;
    totalFare:any;
   
    
    constructor(bookingId,busId,passengerNames,seatsBooked,totalFare,seatNo)
    {
        this.bookingId=bookingId;
        this.busId=busId;
        this.passengerNames=passengerNames;
        this.seatsBooked=seatsBooked;
      
        this.totalFare=totalFare;
       this.seatNo= seatNo;
    }
}