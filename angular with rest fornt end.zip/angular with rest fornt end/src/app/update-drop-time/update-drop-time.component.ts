import { AdminDataService } from './../admin-data.service';
import { BusClass } from './../BusClass';
import { Component, OnInit } from '@angular/core';
import { BusService } from 'src/app/bus.service';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Bus } from 'src/app/Bus';
import { catchError } from 'rxjs/operators';
import { HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';

@Component({
  selector: 'app-update-drop-time',
  templateUrl: './update-drop-time.component.html',
  styleUrls: ['./update-drop-time.component.css']
})
export class UpdateDropTimeComponent implements OnInit {
   flag1:boolean;
   tempBus:Bus;
   bus:BusClass[];
  
  constructor(private adminSer:AdminDataService, private router:Router) { }
  updateDroptime=new FormGroup({
    busId:new FormControl('',Validators.required),
    dropTime:new FormControl('',Validators.required)
  })
  ngOnInit(): void {
    this.adminSer.getBus().subscribe(data=>this.bus=data);
  }
 
  updateDropTime(){
    let busId=this.updateDroptime.get('busId').value;
    let dropTime=this.updateDroptime.get('dropTime').value;
    this.adminSer.updateBusByDropTime(busId, dropTime).pipe(catchError((error:HttpErrorResponse)=>{
      this.router.navigate(["show-error",error.error.message]);
      return throwError(error.error.message)})).subscribe(data=>console.log(data));
    
    for(let i=0;i<this.bus.length;i++)
    {
      if(this.bus[i].busId==busId)
      {
        this.adminSer.updateBusByDropTime(busId, dropTime).subscribe(data=>(console.log(data)));
        this.flag1=true;
      }
    }
  }

}
