package com.cg.obtrs.dto;

public class BusDto {
	private Integer busId;
	private String sourceStation;
	private String destinationStation;
	private String boardingTime;
	private String dropTime;
	private String busType;
	private Integer totalSeats;
	private Float fare;
	private Integer seatsBooked;
	
	public BusDto() {
		super();
	}

	public BusDto(Integer busId, String sourceStation, String destinationStation, String boardingTime, String dropTime,
			String busType, Integer totalSeats, Float fare, Integer seatsBooked) {
		super();
		this.busId = busId;
		this.sourceStation = sourceStation;
		this.destinationStation = destinationStation;
		this.boardingTime = boardingTime;
		this.dropTime = dropTime;
		this.busType = busType;
		this.totalSeats = totalSeats;
		this.fare = fare;
		this.seatsBooked = seatsBooked;
	}

	public Integer getBusId() {
		return busId;
	}

	public void setBusId(Integer busId) {
		this.busId = busId;
	}

	public String getSourceStation() {
		return sourceStation;
	}

	public void setSourceStation(String sourceStation) {
		this.sourceStation = sourceStation;
	}

	public String getDestinationStation() {
		return destinationStation;
	}

	public void setDestinationStation(String destinationStation) {
		this.destinationStation = destinationStation;
	}

	public String getBoardingTime() {
		return boardingTime;
	}

	public void setBoardingTime(String boardingTime) {
		this.boardingTime = boardingTime;
	}

	public String getDropTime() {
		return dropTime;
	}

	public void setDropTime(String dropTime) {
		this.dropTime = dropTime;
	}

	public String getBusType() {
		return busType;
	}

	public void setBusType(String busType) {
		this.busType = busType;
	}

	public Integer getTotalSeats() {
		return totalSeats;
	}

	public void setTotalSeats(Integer totalSeats) {
		this.totalSeats = totalSeats;
	}

	public Float getFare() {
		return fare;
	}

	public void setFare(Float fare) {
		this.fare = fare;
	}

	public Integer getSeatsBooked() {
		return seatsBooked;
	}

	public void setSeatsBooked(Integer seatsBooked) {
		this.seatsBooked = seatsBooked;
	}

	@Override
	public String toString() {
		return "BusDto [busId=" + busId + ", sourceStation=" + sourceStation + ", destinationStation="
				+ destinationStation + ", boardingTime=" + boardingTime + ", dropTime=" + dropTime + ", busType="
				+ busType + ", totalSeats=" + totalSeats + ", fare=" + fare + ", seatsBooked=" + seatsBooked + "]";
	}
	
}
