package com.cg.obtrs.entities;

import java.math.BigInteger;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
public class BusEntity implements Comparable<BusEntity> {
	@Id
	private Integer busId;
	private String sourceStation;
	private String destinationStation;
	private String boardingTime;
	private String dropTime;
	private String busType;
	private Integer totalSeats;
	private Float fare;
	private Integer seatsBooked;

	public BusEntity(Integer busId, String sourceStation, String destinationStation, String boardingTime, String dropTime,
			String busType, Integer totalSeats, Float fare, Integer seatsBooked) {
		super();
		this.busId = busId;
		this.sourceStation = sourceStation;
		this.destinationStation = destinationStation;
		this.busType = busType;
		this.fare = fare;
		this.totalSeats = totalSeats;
		this.boardingTime = boardingTime;
		this.dropTime = dropTime;
		this.seatsBooked = seatsBooked;
	}

	public BusEntity() {
		super();
	}

	public Integer getSeatsBooked() {
		return seatsBooked;
	}

	public void setSeatsBooked(Integer seatsBooked) {
		this.seatsBooked = seatsBooked;
	}

	public String getSourceStation() {
		return sourceStation;
	}

	public void setSourceStation(String sourceStation) {
		this.sourceStation = sourceStation;
	}

	public String getDestinationStation() {
		return destinationStation;
	}

	public void setDestinationStation(String destinationStation) {
		this.destinationStation = destinationStation;
	}

	public String getBusType() {
		return busType;
	}

	public void setBusType(String busType) {
		this.busType = busType;
	}

	public Integer getTotalSeats() {
		return totalSeats;
	}

	public void setTotalSeats(Integer totalSeats) {
		this.totalSeats = totalSeats;
	}

	public Float getFare() {
		return fare;
	}

	public void setFare(Float fare) {
		this.fare = fare;
	}

	public String getBoardingTime() {
		return boardingTime;
	}

	public void setBoardingTime(String boardingTime) {
		this.boardingTime = boardingTime;
	}

	public String getDropTime() {
		return dropTime;
	}

	public void setDropTime(String dropTime) {
		this.dropTime = dropTime;
	}

	public Integer getBusId() {
		return busId;
	}

	public void setBusId(Integer busId) {
		this.busId = busId;
	}

	@Override
	public String toString() {
		DateTimeFormatter format1 = DateTimeFormatter.ofPattern("yyyy-mm-dd hh:mm:ss");
		return "\n\t\tBus Id:" + busId + "\n" + "\n\t\tSource Station:" + sourceStation + "\n"
				+ "\n\t\tDestination Station:" + destinationStation + "\n" + "\n\t\tBoarding Time:" + boardingTime
				+ "\n" + "\n\t\tDropTime:" + dropTime + "\n" + "\n\t\tBus Type:" + busType + "\n" + "\n\t\tTotal Seats:"
				+ totalSeats + "\n" + "\n\t\tFare:" + fare +"\n" + "\n\t\tSeats Booked:" + seatsBooked + "\n\t";
	}

	public static final Comparator<BusEntity> departureComparator = new Comparator<BusEntity>() {
		@Override
		public int compare(BusEntity bus1, BusEntity bus2) {
			return bus1.getBoardingTime().compareTo(bus2.getBoardingTime());
		}
	};

	public static final Comparator<BusEntity> arrivalComparator = new Comparator<BusEntity>() {
		@Override
		public int compare(BusEntity bus1, BusEntity bus2) {
			return bus1.getBoardingTime().compareTo(bus2.getBoardingTime());
		}
	};

	@Override
	public int compareTo(BusEntity bus) {
		return this.busId - bus.busId;
	}
}
