package com.cg.obtrs.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.obtrs.entities.AdminEntity;

public interface AdminDao extends JpaRepository<AdminEntity, Integer>{

}
