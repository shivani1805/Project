package com.cg.obtrs.entities;

import java.math.BigInteger;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Booking")
public class BookingEntity {
	@Id
	@Column(name = "BOOKING_ID")
	private BigInteger bookingId;
	@Column(name = "BUS_ID")
	private BigInteger busId;
	@Column(name = "BOOKING_DATE")
	private Date bookingDate;
	@Column(name="PASSENGER_NAMES")
	private String passengerNames;
	@Column(name = "SEATS_BOOKED")
	private Integer seatsBooked;
	@Column(name = "TOTAL_FARE")
	private float totalFare;
	@Column(name = "seat_no")
	private String seatNo;

	public BookingEntity() {

	}

	public BookingEntity(BigInteger busId, String passengerNames, Integer seatsBooked, float totalFare, BigInteger bookingId,
			String seatNo, Date bookingDate) {
		super();
		this.busId = busId;
		this.passengerNames = passengerNames;
		this.seatsBooked = seatsBooked;
		this.totalFare = totalFare;
		this.bookingId = bookingId;
		this.seatNo = seatNo;
		this.bookingDate = bookingDate;
	}

	public BigInteger getBusId() {
		return busId;
	}

	public void setBusId(BigInteger busId) {
		this.busId = busId;
	}

	public Integer getSeatsBooked() {
		return seatsBooked;
	}

	public void setSeatsBooked(Integer seatsBooked) {
		this.seatsBooked = seatsBooked;
	}

	public String getPassengerNames() {
		return passengerNames;
	}

	public void setPassengerNames(String passengerNames) {
		this.passengerNames = passengerNames;
	}

	public float getTotalFare() {
		return totalFare;
	}

	public void setTotalFare(float totalFare) {
		this.totalFare = totalFare;
	}

	public BigInteger getBookingId() {
		return bookingId;
	}

	public void setBookingId(BigInteger bookingId) {
		this.bookingId = bookingId;
	}

	public String getSeatNo() {
		return seatNo;
	}

	public void setSeatNo(String seatNo) {
		this.seatNo = seatNo;
	}

	public Date getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(Date bookingDate) {
		this.bookingDate = bookingDate;
	}

	@Override
	public String toString() {
		return "BookingDTO [busId=" + busId + ", passengerNames=" + passengerNames + ", seatsBooked=" + seatsBooked
				+ ", totalFare=" + totalFare + "]";
	}

}
