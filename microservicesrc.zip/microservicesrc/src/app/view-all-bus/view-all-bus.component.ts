import { Component, OnInit } from '@angular/core';
import { Bus } from 'src/app/Bus';
import { Router } from '@angular/router';
import{BusService} from 'src/app/bus.service';
import { AdminDataService } from '../admin-data.service';
import { BusClass } from '../BusClass';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { catchError } from 'rxjs/operators';
import { HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';
import { RemoveBusComponent } from '../remove-bus/remove-bus.component';
import {Injectable} from '@angular/core';
import { BusServiceService } from '../bus-service.service';


@Component({
  selector: 'app-view-all-bus',
  templateUrl: './view-all-bus.component.html',
  styleUrls: ['./view-all-bus.component.css']
})
export class ViewAllBusComponent implements OnInit {
  flag1:boolean=false;
  checkEmptyFlag:boolean;
  bus:BusClass[];
  removeObject:RemoveBusComponent;
  currentBus:BusClass[];

  
  constructor(private adminSer:AdminDataService,private busSer:BusService,private router:Router) { }
 
  ngOnInit(): void {
    document.getElementById("busTable").style.display="none";
    this.adminSer.getBus().subscribe(data=>this.bus=data);
    console.log(this.bus);
    document.getElementById("busTable").style.display="block";

  }
  removeBus(busId){
    this.adminSer.getBus().subscribe(data => this.bus=data);
      this.adminSer.deleteBus(busId).pipe(catchError((error:HttpErrorResponse)=>{
      this.router.navigate(["show-error",error.error.message]);
      return throwError(error.error.message)})).subscribe(data=>console.log(data));
        for(let i=0;i<this.bus.length;i++)
        {
          if(this.bus[i].busId==busId)
          {
            this.flag1=true;
            this.bus.splice(i,1);
            this.adminSer.deleteBus(busId).subscribe(data=>(console.log(data)));
           
          }
        }
       window.location.reload();
        
  }
  moveToUpdateBus(busId){
    this.adminSer.getBus().subscribe(data=>this.bus=data);
    console.log(this.bus);
    for(let i=0;i<this.bus.length;i++)
    {
      if(this.bus[i].busId==busId)
      {
        this.busSer.tempBus=this.bus[i];
      }
    }
    //this.busSer.tempBus=busId;
    this.router.navigate(['update-details']);

  }
  

}