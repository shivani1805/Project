export class BusClass
{
    id:any;
    busId:any;
    sourceStation:any;
    destinationStation:any;
    boardingTime:any;
    dropTime:any;
    busType:any;
    totalSeats:any;
    fare:any;
    SeatNo:any;
    seatsBooked:any;
    constructor(busId,sourceStation,destinationStation,boardingTime,dropTime,busType,totalSeats,fare,seatNo,seatsBooked) 
    {
        this.busId=busId;
        this.sourceStation = sourceStation;
        this.destinationStation = destinationStation;
        this.busType = busType;
        this.fare = fare;
        this.SeatNo = seatNo;
        this.totalSeats=totalSeats;
        this.boardingTime = boardingTime;
        this.dropTime = dropTime;
        this.seatsBooked= seatsBooked;
    }
}