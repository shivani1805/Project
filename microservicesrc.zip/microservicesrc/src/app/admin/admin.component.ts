import { AdminDataService } from './../admin-data.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';



@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  constructor(private router: Router,private adminSer: AdminDataService) { }


  loginAdmin = new FormGroup({
    adminEmail: new FormControl('', [Validators.email]),
    password: new FormControl('', Validators.required)
  });


  ngOnInit(): void {
  }
  login() {

    let email = this.loginAdmin.get('adminEmail').value;
    let password = this.loginAdmin.get('password').value;
    this.adminSer.login(email,password).subscribe(data => {
      if(!data)
      {
        window.alert("Invalid Login Credentials");
      }
      else{
        this.router.navigate(["add-bus-or-route"]);
      }
    });
  }
  }
