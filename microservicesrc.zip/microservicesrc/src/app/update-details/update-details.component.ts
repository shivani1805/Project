import { Component, OnInit, Input } from '@angular/core';
import{Router} from '@angular/router';
import{Injectable} from '@angular/core';
import { BusClass } from '../BusClass';
import { AdminDataService } from '../admin-data.service';
import { Bus } from '../Bus';
import { BusService } from '../bus.service';
import { FormGroup, Validators, FormControl } from '@angular/forms';

@Component({
  selector: 'app-update-details',
  templateUrl: './update-details.component.html',
  styleUrls: ['./update-details.component.css']
})
export class UpdateDetailsComponent implements OnInit {
   busId:number;
  bus:Bus;
 currentBusId:Bus;
  
  constructor(private adminSer:AdminDataService,private busSer:BusService,private router:Router) { 

  }
modifyBus=new FormGroup({
  id:new FormControl('',Validators.required),
  sourceStation: new FormControl('',Validators.required),
  destinationStation:new FormControl(''),
  boardingTime:new FormControl(),
  dropTime: new FormControl(''),
  busType:new FormControl(''),
  totalSeats:new FormControl(''),
  fare:new FormControl(''),
})
  ngOnInit(): void {
    this.bus=this.busSer.tempBus;
  }
 /* moveToUpdateBoardingTime(){
    this.router.navigate(['update-boarding-time']);
  }
  moveToUpdateDropTime(){
    this.router.navigate(['update-drop-time']);
  }
 moveToUpdateSourceStation(){
   this.router.navigate(['update-source-station']);
 }
 moveToUpdateDestinationStation(){
   this.router.navigate(['update-destination-station']);
 }
 moveToUpdateBusType(){
   this.router.navigate(['/update-bus-type']);
 }
 moveToUpdateTotalSeats(){
   this.router.navigate(['update-seats']);
 }
 moveToUpdateFare(){
   this.router.navigate(['update-fare']);
 }*/
 updateBus(){
  let sourceStation=this.modifyBus.get('sourceStation').value;
  
      this.adminSer.updateBusBySourceStation(this.bus.id,sourceStation).subscribe(data => console.log(data));
      
    

  

 }
}
