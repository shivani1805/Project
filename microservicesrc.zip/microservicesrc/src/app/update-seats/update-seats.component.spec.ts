import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateSeatsComponent } from './update-seats.component';

describe('UpdateSeatsComponent', () => {
  let component: UpdateSeatsComponent;
  let fixture: ComponentFixture<UpdateSeatsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateSeatsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateSeatsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
